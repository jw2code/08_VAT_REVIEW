# csv 는 파이썬에 기본으로 들어 있는 도구다. 따로 설치할 게 없다.
# 쉼표로 나뉜 파일을 알아서 칸별로 잘라준다
import csv

for name in ["customers.csv", "products.csv", "purchases.csv"]:
    # open 은 파일을 연다. encoding="utf-8" 은 "한글이 든 파일이다" 라고 알려주는 것이다.
    # 이걸 안 적으면 윈도우에서 한글이 깨지거나 에러가 난다.
    # with 로 열면 블록이 끝날 때 파이썬이 알아서 파일을 닫아준다
    with open(f"data/{name}", encoding="utf-8") as f:
        # DictReader 는 첫 줄을 "칸 이름"으로 보고, 나머지 줄을 딕셔너리로 만들어준다.
        #   {'customer_id': 'C001', 'name': '박은수', ...}
        # 그냥 두면 한 줄씩 흘려보내는 물건이라, list() 로 감싸 전부 꺼내 담는다
        rows = list(csv.DictReader(f))

    print("==", name, len(rows), "줄")      # len 은 개수를 센다
    print("칸 이름:", list(rows[0]))        # 표[0] = 첫 줄. list() 로 감싸면 칸 이름만 나온다
    print("첫 줄  :", rows[0])
    print()                              # 빈 줄 하나
